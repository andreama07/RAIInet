#include "observer.h"

using namespace std;

void Observer::notify(Link &l, string action, char winner) {
    // this->notify(l);
}  // l is the Link that called the notify method

